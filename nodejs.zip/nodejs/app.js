const path = require('path');

const express = require('express');
const bodyParser = require('body-parser');

const sequelize = require('./util/database');

const Files = require('./models/files');
const Folders = require('./models/folder');
const Users = require('./models/user');

const app = express();

app.set('view engine', 'ejs');
app.set('views', 'views');

const UserRoutes = require('./routes/user');


app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(UserRoutes);

Folders.belongsTo(Users, { constraints: true, onDelete: 'CASCADE' });
Users.hasMany(Folders);

Files.belongsTo(Folders, { constraints: true, onDelete: 'CASCADE' });
Folders.hasMany(Files);

sequelize.sync({ force: true })
    .then(result => {
        app.listen(3000);
    })
    .catch(err => console.log(err));