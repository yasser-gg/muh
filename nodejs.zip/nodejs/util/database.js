const Sequelize = require('sequelize');

const sequelize = new Sequelize('node-complet', 'root', 'nodecomplet', { dialect: 'mysql', host: 'localhost' });

module.exports = sequelize;