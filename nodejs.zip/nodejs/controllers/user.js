const Folders = require('../models/folder');
const Users = require('../models/user');
const Files = require('../models/files');
const fs = require('fs');

let id = 0;
let FolderId = 0;

exports.getUser = (req, res, next) => {
    const userId = req.params.userId;
    Folders.findAll({ where: { userId: userId } })
        .then(stuffs => {
            res.render('user', {
                stuffs: stuffs,
                id: id
            });

        })
        .catch(err => console.log(err));

};

exports.postUser = (req, res, next) => {
    FolderId = req.body.FolderId;
    console.log(FolderId);

    res.redirect('/user/Folder/showFiles');


};

exports.getAddFile = (req, res, next) => {

    res.render('addFile');

};

exports.postAddFile = (req, res, next) => {

    const name = req.body.title;
    const url = req.body.file

    var imageData = fs.readFileSync(url);

    Files.create({ name: name, data: imageData, folderId: FolderId }).then(() => {
        res.redirect('/user/Folder/showFiles');

    }).catch(err => console.log(err));



};




exports.getAddFolder = (req, res, next) => {

    res.render('addFolder');

};

exports.postAddFolder = (req, res, next) => {

    const name = req.body.name;
    Folders.create({ name: name, userId: id }).then(() => {
        res.redirect(`/user/${id}`);
    }).catch(err => console.log(err))


};
exports.getUserIdSelector = (req, res, next) => {

    res.render('userid');

};

exports.postUserIdSelector = (req, res, next) => {

    const id = req.body.id;
    Users.findByPk(id).then(user => {
        req.user = user;

        res.redirect(`/user/${id}`);
    }).catch(err => console.log(err));



};

exports.getCreate = (req, res, next) => {

    res.render('createUser');

};

exports.postCreate = (req, res, next) => {

    const name = req.body.name;

    Users.create({ name: name }).then((user) => {

        id = user.id;
        res.redirect(`/user/${user.id}`);
    }).catch(err => console(err));

};


exports.getShowFiles = (req, res, next) => {


    Files.findAll({ where: { folderId: FolderId } })
        .then((files) => {

            res.render('showFiles', { files: files, id: FolderId });
        })
        .catch();


};

exports.postShowFiles = (req, res, next) => {

    const idddd = req.body.FolderId;



    Files.findByPk(1).then((result) => {


        res.send(result.data);
    }).catch(err => console.log(err));


};