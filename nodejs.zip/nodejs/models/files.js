const Sequelize = require('sequelize');

const seqeulize = require('../util/database');


const Files = seqeulize.define('files', {

    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        allowNull: false,
        autoIncrement: true
    },
    name: {
        type: Sequelize.STRING
    },
    data: {
        type: Sequelize.BLOB('long')
    }




}, {
    freezeTableName: true // Model tableName will be the same as the model name
});

module.exports = Files;