const express = require('express');

const userController = require('../controllers/user');

const router = express.Router();

router.get('/', userController.getUserIdSelector);

router.post('/', userController.postUserIdSelector);

router.get('/create', userController.getCreate);

router.post('/create', userController.postCreate);

router.get('/user/addFolder', userController.getAddFolder);

router.post('/user/addFolder', userController.postAddFolder);

router.get('/user/Folder/showFiles', userController.getShowFiles);

router.post('/user/Folder/showFiles', userController.postShowFiles);

router.get('/user/Folder/showFiles/addFile', userController.getAddFile);

router.post('/user/Folder/showFiles/addFile', userController.postAddFile);

router.post('/user/:userId', userController.postUser);

router.get('/user/:userId', userController.getUser);









module.exports = router;